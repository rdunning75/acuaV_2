# acua

## Install mongo locally and then run this script to add sample data
```
https://www.mongodb.com/download-center/community

mongo script.js

**Run this script to reset the database sample data as well
```

## Run the server
```
npm start

switch comments on lines 12 and 13 under ticketing-manager/src/store/modules/tickets.js
in the ticketing-manager repo to have to data come from this server instead of in-memory
```

[![LoopBack](https://github.com/strongloop/loopback-next/raw/master/docs/site/imgs/branding/Powered-by-LoopBack-Badge-(blue)-@2x.png)](http://loopback.io/)
